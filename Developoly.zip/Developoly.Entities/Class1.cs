﻿using System;

namespace Developoly.Entities
{
    public class Class1
    {
    }
}
