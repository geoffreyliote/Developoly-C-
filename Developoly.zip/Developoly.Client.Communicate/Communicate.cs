﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Developoly.Client.Communicate
{
    public static class Communicate
    {

        public static void NextPage()
        {
            
        }
    }
}
