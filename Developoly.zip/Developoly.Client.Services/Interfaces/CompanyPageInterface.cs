﻿using Developoly.Client.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Developoly.Client.Services.Interfaces
{
    public interface CompanyPageInterface
    {
        General General { get; set; }



    }
}
